# innobackupex_cli_menu
Utility wrapper around innobackupex for scheduled backup routines from MySQL servers
